"""
og_core.py -- ubwenge bw'ingenzi bwa The_Og API (nta FastAPI, nta database).
Bukoresha gusa: stdlib + (openai, anthropic nk'uko bikenewe).
"""
import collections
import hashlib
import json
import logging
import os
import secrets
import threading
import time
from collections import namedtuple

log = logging.getLogger("og_api")

# ----------------------------------------------------------------------------
# ⚙️ ENV
# ----------------------------------------------------------------------------
def env(name, default=None):
    v = os.environ.get(name)
    return v if v not in (None, "") else default


def as_list(v):
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x).strip() for x in v if str(x).strip()]
    text = str(v).strip()
    if text.startswith("["):  # JSON list
        try:
            return [str(x).strip() for x in json.loads(text) if str(x).strip()]
        except Exception:
            pass
    return [x.strip().strip('"').strip("'") for x in text.replace("\n", ",").split(",") if x.strip()]


def valid_key(k):
    k = (k or "").strip()
    low = k.lower()
    return bool(k) and "xxxx" not in low and not low.startswith(("put_", "your_", "paste_"))


# ----------------------------------------------------------------------------
# 🔌 PROVIDERS (keys nyazo ziba muri ENV y'iseriveri gusa)
# ----------------------------------------------------------------------------
PROVIDERS = {
    "groq": {"base_url": "https://api.groq.com/openai/v1", "chat": "llama-3.3-70b-versatile",
             "vision": "meta-llama/llama-4-scout-17b-16e-instruct"},
    "openai": {"base_url": None, "chat": "gpt-4o-mini", "vision": "gpt-4o-mini"},
    "gemini": {"base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
               "chat": "gemini-2.5-flash", "vision": "gemini-2.5-flash", "alias": ["GOOGLE_API_KEY"]},
    "anthropic": {"base_url": None, "chat": "claude-sonnet-5-5", "vision": "claude-sonnet-5-5"},
    "mistral": {"base_url": "https://api.mistral.ai/v1", "chat": "mistral-small-latest",
                "vision": "mistral-small-latest"},
    "deepseek": {"base_url": "https://api.deepseek.com", "chat": "deepseek-chat"},
    "openrouter": {"base_url": "https://openrouter.ai/api/v1", "chat": "openai/gpt-4o-mini",
                   "vision": "openai/gpt-4o-mini"},
    "together": {"base_url": "https://api.together.xyz/v1", "chat": "meta-llama/Llama-3.3-70B-Instruct-Turbo"},
    "xai": {"base_url": "https://api.x.ai/v1", "chat": "grok-3-mini"},
    "custom": {"base_url": None},
}
DEFAULT_ORDER = list(PROVIDERS)
Cand = namedtuple("Cand", "provider key base_url model")


def get_keys(provider):
    P = provider.upper()
    names = [f"{P}_API_KEY", f"{P}_API_KEYS"] + PROVIDERS[provider].get("alias", [])
    seen, out = set(), []
    for n in names:
        for k in as_list(env(n)):
            if valid_key(k) and k not in seen:
                seen.add(k)
                out.append(k)
    return out


def candidates(cap):
    """cap = chat | vision"""
    import random

    order = [o.lower() for o in as_list(env("PROVIDER_ORDER"))] or DEFAULT_ORDER
    order += [p for p in DEFAULT_ORDER if p not in order]
    out = []
    for p in order:
        cfg = PROVIDERS.get(p)
        if not cfg:
            continue
        P = p.upper()
        model = env(f"{P}_MODEL" if cap == "chat" else f"{P}_{cap.upper()}_MODEL", cfg.get(cap))
        base = env(f"{P}_BASE_URL", cfg.get("base_url"))
        if not model or (p == "custom" and not base):
            continue
        keys = get_keys(p)
        random.shuffle(keys)
        out += [Cand(p, k, base, model) for k in keys]
    return out


# ---- clients (zishobora gusimburwa mu bizamini) ----
_clients = {}


def make_openai(key, base_url):
    k = ("o", key, base_url)
    if k not in _clients:
        from openai import OpenAI

        _clients[k] = OpenAI(api_key=key, base_url=base_url, timeout=60.0, max_retries=0)
    return _clients[k]


def make_anthropic(key):
    k = ("a", key)
    if k not in _clients:
        import anthropic

        _clients[k] = anthropic.Anthropic(api_key=key, timeout=60.0, max_retries=0)
    return _clients[k]


# ---- failover: key yapfuye ihabwa akaruhuko ----
_bad = {}
_bad_lock = threading.Lock()
COOLDOWN = 300


def _fp(c):
    return (c.provider, c.key[-6:])


def mark_bad(c, err):
    msg = str(err).lower()
    code = getattr(err, "status_code", None)
    if code in (401, 402, 403, 429) or "quota" in msg or "credit" in msg:
        with _bad_lock:
            _bad[_fp(c)] = time.time() + COOLDOWN


def rank(cands):
    now = time.time()
    with _bad_lock:
        good = [c for c in cands if _bad.get(_fp(c), 0) < now]
    return good + [c for c in cands if c not in good]


class UpstreamError(Exception):
    pass


# ----------------------------------------------------------------------------
# 💬 MESSAGES
# ----------------------------------------------------------------------------
DEFAULT_IDENTITY = (
    "You are The_Og AI, a smart, warm and helpful assistant. Be clear, accurate and friendly. "
    "If asked which model, company or technology powers you, say you are The_Og AI and that "
    "you can't share details about the underlying technology."
)


def clean_messages(raw):
    """Gusukura 'messages' z'umukiriya (OpenAI format). Zishobora guteza ValueError."""
    if not isinstance(raw, list) or not raw:
        raise ValueError("'messages' must be a non-empty array.")
    out, total = [], 0
    for m in raw[-60:]:
        if not isinstance(m, dict):
            continue
        role = m.get("role")
        if role == "developer":
            role = "system"
        if role not in ("system", "user", "assistant"):
            continue
        c = m.get("content")
        if isinstance(c, str):
            total += len(c)
        elif isinstance(c, list):
            parts = []
            for p in c:
                if not isinstance(p, dict):
                    continue
                if p.get("type") == "text" and isinstance(p.get("text"), str):
                    parts.append({"type": "text", "text": p["text"]})
                    total += len(p["text"])
                elif p.get("type") == "image_url":
                    iu = p.get("image_url")
                    url = iu.get("url") if isinstance(iu, dict) else iu
                    if isinstance(url, str) and url.startswith("data:image/") and ";base64," in url:
                        parts.append({"type": "image_url", "image_url": {"url": url}})
                        total += 1000
            c = parts
        else:
            continue
        if not c:
            continue
        out.append({"role": role, "content": c})
    if not any(m["role"] == "user" for m in out):
        raise ValueError("At least one 'user' message is required.")
    if total > 600_000:
        raise ValueError("Request is too large.")
    return out


def has_image(messages):
    return any(
        isinstance(m["content"], list) and any(p.get("type") == "image_url" for p in m["content"])
        for m in messages
    )


def with_identity(messages):
    ident = env("OG_SYSTEM_PROMPT", DEFAULT_IDENTITY)
    return ([{"role": "system", "content": ident}] if ident.strip() else []) + messages


def to_anthropic(messages):
    system_parts, out = [], []
    for m in messages:
        c = m["content"]
        if m["role"] == "system":
            system_parts.append(c if isinstance(c, str) else " ".join(p.get("text", "") for p in c))
            continue
        if isinstance(c, list):
            blocks = []
            for p in c:
                if p.get("type") == "text":
                    blocks.append({"type": "text", "text": p["text"]})
                elif p.get("type") == "image_url":
                    head, data = p["image_url"]["url"].split(",", 1)
                    media = head.split(";")[0].replace("data:", "") or "image/jpeg"
                    blocks.append({"type": "image", "source": {"type": "base64", "media_type": media, "data": data}})
            c = blocks
        if c:
            out.append({"role": m["role"], "content": c})
    return "\n\n".join(system_parts), out


# ----------------------------------------------------------------------------
# 🤖 UPSTREAM (failover hagati ya providers/keys)
# ----------------------------------------------------------------------------
def iter_text(messages, vision=False, max_tokens=1024, temperature=None):
    cands = rank(candidates("vision" if vision else "chat"))
    last = None
    for c in cands:
        got = False
        try:
            if c.provider == "anthropic":
                system, am = to_anthropic(messages)
                with make_anthropic(c.key).messages.stream(
                    model=c.model, max_tokens=max_tokens, system=system, messages=am
                ) as s:
                    for t in s.text_stream:
                        if t:
                            got = True
                            yield t
            else:
                kw = {"model": c.model, "messages": messages, "stream": True, "max_tokens": max_tokens}
                if temperature is not None:
                    kw["temperature"] = temperature
                for ch in make_openai(c.key, c.base_url).chat.completions.create(**kw):
                    if not ch.choices:
                        continue
                    d = ch.choices[0].delta.content
                    if d:
                        got = True
                        yield d
            if got:
                return
        except Exception as e:  # noqa
            last = e
            log.warning("upstream %s failed: %s", c.provider, str(e)[:200])
            mark_bad(c, e)
            if got:
                return
    raise UpstreamError(str(last) if last else "no providers configured")


def prime(gen):
    """Gusoma igice cya mbere; iyo byose byapfuye -> UpstreamError (mbere yo kohereza headers)."""
    try:
        return next(gen)
    except StopIteration:
        raise UpstreamError("empty response")


# ----------------------------------------------------------------------------
# 📤 OPENAI-FORMAT RESPONSES
# ----------------------------------------------------------------------------
def approx_tokens(text):
    return max(1, len(text) // 4)


def _json(o):
    return json.dumps(o, ensure_ascii=False)


def sse_stream(first, rest, model):
    cid = "chatcmpl-og" + secrets.token_hex(8)
    created = int(time.time())

    def chunk(delta, finish=None):
        return "data: " + _json({
            "id": cid, "object": "chat.completion.chunk", "created": created, "model": model,
            "choices": [{"index": 0, "delta": delta, "finish_reason": finish}],
        }) + "\n\n"

    yield chunk({"role": "assistant", "content": ""})
    yield chunk({"content": first})
    for t in rest:
        yield chunk({"content": t})
    yield chunk({}, "stop")
    yield "data: [DONE]\n\n"


def completion_payload(text, model, prompt_text=""):
    pt, ct = approx_tokens(prompt_text), approx_tokens(text)
    return {
        "id": "chatcmpl-og" + secrets.token_hex(8), "object": "chat.completion",
        "created": int(time.time()), "model": model,
        "choices": [{"index": 0, "message": {"role": "assistant", "content": text}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": pt, "completion_tokens": ct, "total_tokens": pt + ct},
    }


def prompt_text(messages):
    parts = []
    for m in messages:
        c = m["content"]
        parts.append(c if isinstance(c, str) else " ".join(p.get("text", "") for p in c))
    return "\n".join(parts)


# ----------------------------------------------------------------------------
# 🔑 API KEYS ZAWE (og-...) -- hashes gusa ni zo zibikwa
# ----------------------------------------------------------------------------
KEY_PREFIX = "og-"


def new_api_key():
    plain = KEY_PREFIX + secrets.token_urlsafe(32)
    return plain, plain[:10], hash_key(plain)


def hash_key(plain):
    return hashlib.sha256(plain.encode()).hexdigest()


class RateLimiter:
    def __init__(self):
        self.hits = {}
        self.lock = threading.Lock()

    def allow(self, key, limit, window=60.0):
        if limit <= 0:
            return True
        now = time.monotonic()
        with self.lock:
            dq = self.hits.setdefault(key, collections.deque())
            while dq and now - dq[0] > window:
                dq.popleft()
            if len(dq) >= limit:
                return False
            dq.append(now)
            return True
